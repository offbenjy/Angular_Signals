export interface Delivery {
  id: number;
  name: string;
  amount:number;
  user: string;
  date: string;
  price: number;
  role: string;
}
